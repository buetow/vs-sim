package events;

public interface VSEvent {
}
