package prefs;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.io.*;

public class VSDefaultPrefs extends VSPrefs {
    public static VSPrefs initialize() {
        return initialize(VSPrefs.PREFERENCES_FILENAME);
    }

    public static VSPrefs initialize(String fileName) {
        File file = new File(fileName);
        VSPrefs prefs = null;

        if (file.exists()) {
            prefs = openFile(fileName);

        } else {
            prefs = new VSDefaultPrefs();
            prefs.fillWithDefaults();
        }

        return prefs;
    }

    public void saveFile() {
        super.saveFile(VSPrefs.PREFERENCES_FILENAME);
    }

    public void fillWithDefaults() {
        super.clear();
        fillDefaultColors();
        fillDefaultFloats();
        fillDefaultIntegers();
        fillDefaultLongs();
        fillDefaultStrings();
        fillDefaultBooleans();
    }

    public void fillDefaultStrings() {
        /* Internal prefs */
        initString("lang.time.lamport", "Lamport");
        initString("lang.message.sent", "Nachricht versendet");
        initString("lang.logging.active", "Logging");
        initString("lang.message", "Nachricht");
        initString("lang.message.recv", "Nachricht erhalten");
        initString("lang.about", "About");
        initString("lang.about.info!", "Dieses Programm wurde von Paul B�tow im Rahmen der Diplomarbeit bei Prof. Dr.-Ing. O�mann erstellt. Dieses Programm stellt noch keinesfalls eine fertige Version dar, da es sich noch in Entwicklung befindet und die Diplomarbeit erst mitte August abgeschlossen sein wird! Bei Fehlern bitte eine kurze Mail mitsamt Fehlerbeschreibung an paul@buetow.org schicken! Dieser Simulator wird sp�ter au�erdem unter einer open source Linzenz (wahrscheinlich der GNU General Public License) freigegeben!");
        initString("lang.cancel", "Abbrechen");
        initString("lang.close", "Schliessen");
        initString("lang.requesttime", "Requestzeit");
        initString("lang.colorchooser", "Farbauswahl");
        initString("lang.colorchooser2", "Bitte Farbe ausw�hlen");
        initString("lang.default", "Defaults");
        initString("lang.remove", "Entfernen");
        initString("lang.edit", "Editieren");
        initString("lang.editor", "Editor");
        initString("lang.activate", "aktivieren");
        initString("lang.activated", "Aktiviert");
        initString("lang.server", "Server");
        initString("lang.client", "Client");
        initString("lang.type", "Typ");
        initString("lang.taskmanager", "Taskmanager");
        initString("lang.protocol", "Protokoll");
        initString("lang.protocol.editor", "Protokolleditor");
        initString("lang.protocol.tasks.activation", "Client-/Serverprotokoll Aktivierung");
        initString("lang.protocol.tasks.client", "Client Task-Manager (Clientanfragen)");
        //initString("lang.protocol.tasks.server", "Server Task-Manager (onServerStart Schedule)");
        initString("lang.protocol.client", "Clientseite");
        initString("lang.protocol.server", "Serverseite");
        initString("lang.file", "Datei");
        initString("lang.new", "Neu");
        initString("lang.ok", "OK");
        initString("lang.actualize", "Aktualisieren");
        initString("lang.takeover", "�bernehmen");
        initString("lang.open", "�ffnen");
        initString("lang.pause", "Pausieren");
        initString("lang.prefs", "Einstellungen");
        initString("lang.prefs.more", "Mehr Einstellungen");
        initString("lang.prefs.ext", "Erweiterte Einstellungen");
        initString("lang.prefs.info!", "Prozesseinstellungen k�nnen sp�ter f�r jeden Prozess einzelnd eingestellt werden.Die folgenden Werte sind lediglich die globalen Defaultwerte, die f�r neue Prozesse verwendet werden!");
        initString("lang.prefs.protocol", "Protokolleinstellungen");
        initString("lang.prefs.process", "Prozesseinstellungen");
        initString("lang.prefs.process.ext", "Erweiterte Prozesseinstellungen");
        initString("lang.prefs.process.info!", "�nderungen werden erst nach Bet�tigen des \"�bernehmen\" oder \"OK\" Knopfes �bernommen!");
        initString("lang.prefs.protocol.info!", "�nderungen werden erst nach Bet�tigen des \"�bernehmen\" oder \"OK\" Knopfes �bernommen!");
        initString("lang.process.clock.variance", "Uhrabweichung");
        initString("lang.process.id", "PID");
        initString("lang.process.new", "Neuer Prozess");
        //initString("lang.process.prob.delay", "Verz�gerungswahrscheinlichkeit");
        //initString("lang.process.prob.outage", "Ausfallwahrscheinlichkeit");
        initString("lang.process.time.local", "Lokale Zeit");
        initString("lang.quit", "Beenden");
        initString("lang.replay", "Wiederholen");
        initString("lang.reset", "Reset");
        initString("lang.save", "Speichern");
        initString("lang.saveas", "Speichern unter");
        initString("lang.process.task", "Prozess-Task");
        initString("lang.simulation", "Simulation");
        initString("lang.simulation.finished", "Simulation beendet");
        initString("lang.simulation.new", "Neue Simulation");
        initString("lang.simulation.paused", "Simulation pausiert");
        initString("lang.simulation.resetted", "Simulation zur�ckgesetzt");
        initString("lang.simulation.started", "Simulation gestartet");
        initString("lang.start", "Starten");
        initString("lang.stop", "Stoppen");
        initString("name", "Verteilte Systeme v0.1");
    }

    public void fillDefaultIntegers() {
        /* Simulation prefs */
        initInteger("sim.process.num", 3, "Anzahl der Prozesse", 1, 6);
        initIntegerUnit("sim.message.prob.outage", 5, "W'keit, dass eine Nachricht verloren geht", 0, 100, "%");
        initIntegerUnit("sim.process.prob.crash", 5, "W'keit, dass der Prozess ausf�llt", 0, 100, "%");
        initIntegerUnit("sim.seconds", 30, "Simulationsdauer", 5, 120, "s");

        /* Internal prefs */
        initInteger("keyevent.about", KeyEvent.VK_A, null, 0, 100);
        initInteger("keyevent.cancel", KeyEvent.VK_N, null, 0, 100);
        initInteger("keyevent.close", KeyEvent.VK_C, null, 0, 100);
        initInteger("keyevent.default", KeyEvent.VK_F, null, 0, 100);
        initInteger("keyevent.edit", KeyEvent.VK_E, null, 0, 100);
        initInteger("keyevent.file", KeyEvent.VK_D, null, 0, 100);
        initInteger("keyevent.new", KeyEvent.VK_N, null, 0, 100);
        initInteger("keyevent.actualize", KeyEvent.VK_A, null, 0, 100);
        initInteger("keyevent.takeover", KeyEvent.VK_B, null, 0, 100);
        initInteger("keyevent.ok", KeyEvent.VK_O, null, 0, 100);
        initInteger("keyevent.open", KeyEvent.VK_O, null, 0, 100);
        initInteger("keyevent.pause", KeyEvent.VK_P, null, 0, 100);
        initInteger("keyevent.prefs", KeyEvent.VK_P, null, 0, 100);
        initInteger("keyevent.prefs.ext", KeyEvent.VK_E, null, 0, 100);
        initInteger("keyevent.quit", KeyEvent.VK_B, null, 0, 100);
        initInteger("keyevent.replay", KeyEvent.VK_R, null, 0, 100);
        initInteger("keyevent.reset", KeyEvent.VK_R, null, 0, 100);
        initInteger("keyevent.save", KeyEvent.VK_S, null, 0, 100);
        initInteger("keyevent.saveas", KeyEvent.VK_V, null, 0, 100);
        initInteger("keyevent.simulation", KeyEvent.VK_S, null, 0, 100);
        initInteger("keyevent.start", KeyEvent.VK_S, null, 0, 100);
        initInteger("keyevent.stop", KeyEvent.VK_P, null, 0, 100);

        initIntegerUnit("window.prefs.xsize", 400, "X-Gr�sse des Einstellungsfensters", 550, 3200, "px");
        initIntegerUnit("window.prefs.ysize", 650, "Y-Gr�sse des Einstellungsfensters", 640, 2400, "px");
        initIntegerUnit("window.loggsize", 350, "Y-Gr�sse des Loggingfensters", 100, 1000, "px");
        initIntegerUnit("window.splitsize", 180, null, 100, 1000, "px");
        initIntegerUnit("window.xsize", 1024, "X-Gr�sse des Hauptfensters", 800, 3200, "px");
        initIntegerUnit("window.ysize", 768, "Y-Gr�sse des Hauptfensters", 600, 2400, "px");
    }

    public void fillDefaultFloats() {
        /* Simulation prefs */
        initFloat("sim.process.clock.variance", 0, "Uhrabweichung");
    }

    public void fillDefaultLongs() {
        /* Simulation prefs */
        initLongUnit("sim.message.sendingtime.min", 1000, "Minimale Nachrichten�bertragungszeit", "ms");
        initLongUnit("sim.message.sendingtime.max", 5000, "Maximale Nachrichten�bertragungszeit", "ms");
    }

    public void fillDefaultColors() {
        /* Internal prefs */
        initColor("process.default", new Color(0x00, 0x00, 0x00));
        initColor("process.running", new Color(0x0D, 0xD8, 0x09));
        initColor("process.crashed", new Color(0xff, 0x00, 0x00));
        initColor("process.highlight", new Color(0xff, 0xA5, 0x00));
        initColor("process.line", new Color(0x00, 0x00, 0x00));
        initColor("process.secondline", new Color(0xAA, 0xAA, 0xAA));
        initColor("process.sepline", new Color(0xff, 0x00, 0x00));
        initColor("process.stopped", new Color(0x00, 0x00, 0x00));
        initColor("message.arrived", new Color(0x00, 0x85, 0xD2));
        initColor("message.sending", new Color(0x0D, 0xD8, 0x09));
        initColor("message.lost", new Color(0xFF, 0x00, 0x00));
    }

    public void fillDefaultBooleans() {
    }
}
