package exceptions;

public class ParseIntegerVectorException extends Exception {
}
