#!/bin/sh -x

ant $@ 

