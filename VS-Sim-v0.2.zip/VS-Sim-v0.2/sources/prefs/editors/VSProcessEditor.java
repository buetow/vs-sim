/*
 * VS is (c) 2008 by Paul C. Buetow
 * vs@dev.buetow.org
 */
package prefs.editors;

import java.awt.event.*;
import javax.swing.*;
import java.util.*;

import core.*;
import protocols.*;
import events.*;
import prefs.VSPrefs;

/**
 * The Class VSProcessEditor.
 */
public class VSProcessEditor extends VSAbstractBetterEditor {
    private static final long serialVersionUID = 1L;

    /** The process. */
    private VSProcess process;

    /** The TAKEOVE r_ button. */
    public static boolean TAKEOVER_BUTTON;

    /**
     * Instantiates a new lang.process.removeprocess editor.
     *
     * @param prefs the prefs
     * @param process the process
     */
    public VSProcessEditor(VSPrefs prefs, VSProcess process) {
        super(prefs, process, prefs.getString("lang.name") + " - " + prefs.getString("lang.prefs.process"));;
        this.process = process;
        disposeFrameWithParentIfExists();
        makeProtocolVariablesEditable();
    }

    /* (non-Javadoc)
     * @see prefs.editors.VSAbstractBetterEditor#addToButtonPanelFront(javax.swing.JPanel)
     */
    protected void addToButtonPanelFront(JPanel buttonPanel) {
        JButton takeoverButton = new JButton(
            prefs.getString("lang.takeover"));
        takeoverButton.setMnemonic(prefs.getInteger("keyevent.takeover"));
        takeoverButton.addActionListener(this);
        buttonPanel.add(takeoverButton);
    }

    /**
     * Make protocol variables editable.
     */
    protected void makeProtocolVariablesEditable() {
        ArrayList<String> editableProtocolsClassnames =
            VSRegisteredEvents.getEditableProtocolsClassnames();

        //String protocolString = " " + prefs.getString("lang.protocol");
        String clientString = " " + prefs.getString("lang.client");
        String serverString = " " + prefs.getString("lang.server");

        for (String protocolClassname : editableProtocolsClassnames) {
            String protocolShortname = VSRegisteredEvents.getShortnameByClassname(protocolClassname);
            VSAbstractProtocol protocol = process.getProtocolObject(protocolClassname);
            protocol.onClientInit();
            protocol.onServerInit();

            ArrayList<String> clientVariables = VSRegisteredEvents.getProtocolClientVariables(protocolClassname);
            if (clientVariables != null)
                addToEditor(protocolShortname + clientString, protocolShortname, protocol, clientVariables);

            ArrayList<String> serverVariables = VSRegisteredEvents.getProtocolServerVariables(protocolClassname);
            if (serverVariables != null)
                addToEditor(protocolShortname + serverString, protocolShortname, protocol, serverVariables);
        }
    }

    /* (non-Javadoc)
     * @see prefs.editors.VSAbstractBetterEditor#actionPerformed(java.awt.event.ActionEvent)
     */
    public void actionPerformed(ActionEvent e) {
        String actionCommand = e.getActionCommand();

        if (actionCommand.equals(prefs.getString("lang.ok"))) {
            savePrefs();
            process.updateFromVSPrefs();

        } else if (actionCommand.equals(prefs.getString("lang.takeover"))) {
            savePrefs();
            process.updateFromVSPrefs();

        } else {
            super.actionPerformed(e);
        }
    }
}
